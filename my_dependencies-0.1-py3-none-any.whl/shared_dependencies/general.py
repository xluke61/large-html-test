def get_logger():
    print("Logger initialized")
    return "Logger"